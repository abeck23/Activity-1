﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MilesToKilometers
{
    public partial class Converter : Form
    {
        public Converter()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            double distance, convertedDistance;
            if(double.TryParse(txtDistance.Text, out distance))
            {
                if(lstFrom.SelectedIndex != -1)
                {
                    if(lstTo.SelectedIndex != -1)
                    {
                        if(lstFrom.SelectedIndex == 0 && lstTo.SelectedIndex == 0)
                        {
                            MessageBox.Show("Must chose opposite measurements");
                        } 
                        if(lstFrom.SelectedIndex == 0 && lstTo.SelectedIndex == 1)
                        {
                            convertedDistance = distance * .62;
                            lblConvertedDistance.Text = convertedDistance.ToString();
                        }
                        if(lstFrom.SelectedIndex == 1 && lstTo.SelectedIndex == 0)
                        {
                            convertedDistance = distance * 1.609;
                        }
                        if(lstFrom.SelectedIndex == 1 && lstTo.SelectedIndex == 1)
                        {
                            MessageBox.Show("Must choose opposite measurements");
                        }
                    }
                    else MessageBox.Show("Please select measurement: To");
                }
                else
                {
                    MessageBox.Show("Please select measurement: From");
                }
            }
            else
            {
                MessageBox.Show("Enter a number for Distance.");
            }
        }
    }
}
