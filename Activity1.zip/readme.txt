Austin Beck
CST-150
31 July 21
Professor Smithers


	I have successfully downloaded the Visual Studios program.
	I have successfully created a web form with the following 3 tools:
		1. Labels
		2. Button
		3. Text Box

	All 3 are functioning, giving the user the ability to read what information goes in what textbox, input into the text box and click the button to save.